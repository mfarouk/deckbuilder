# Packages needed for various samples:
install.packages(c("dplyr", "ggplot2", "ggthemes", "reshape2", "e1071"), dependencies=T);
