The sample requires the base AdventureWorksDW2016_EXT database

1. Restore the AdventureworksDW2016_EXT
2. Use the ColumnstoreDemo.sql script to walk through some examples

