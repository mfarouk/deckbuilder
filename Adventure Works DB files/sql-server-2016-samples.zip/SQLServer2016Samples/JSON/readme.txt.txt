
				AdventureWorks SQL Server 2016 JSON Sample

	Prerequisites:
	1. AdventureWorks2016_EXT database must be installed.
	Optional:
	Full text search - arrays of scalars might be indexed using FTS. One example in Indexing JSON data script requires FTS to be installed.

	Structure of examples:
	1. De-normalization
	2. Create views that query JSON data
	3. Creating procedures that query JSON data
	4. Indexing JSON data 
	5. JSON import/export
	6. Query examples
	7. Cleanup script

Note: Prerequisite for scripts 2-6 is script 1. Script 1 will create JSON columns and populate data.
